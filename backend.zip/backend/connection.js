const mysql = require("mysql");

// MySQL server configuration
const connection = mysql.createConnection({
  host: "localhost",
  user: "yourusername",
  password: "yourpassword",
  database: "yourdatabase",
});

// Connect to the MySQL database
connection.connect((error) => {
  if (error) {
    console.error("Error connecting to MySQL database:", error.stack);
    return;
  }
  console.log("Connected to MySQL database as ID", connection.threadId);
});

// Perform SQL queries here...
connection.query("SELECT * FROM users", (error, results) => {
  if (error) {
    console.error("Error executing SQL query:", error.stack);
    return;
  }
  console.log("Query results:", results);
});

// Close the MySQL connection
connection.end((error) => {
  if (error) {
    console.error("Error closing MySQL connection:", error.stack);
    return;
  }
  console.log("MySQL connection closed.");
});
