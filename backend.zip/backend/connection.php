<?php
// MySQL server configuration
$servername = "127.0.0.1";
$username = "root";
$password = "1234";
$dbname = "infop";

// Create a MySQL database connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Perform SQL queries here...

// Close the MySQL connection
mysqli_close($conn);
?>
