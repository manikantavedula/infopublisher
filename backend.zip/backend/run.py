from flask import Flask, jsonify, make_response
from flask_cors import CORS
import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), 'api'))
import series

app = Flask(__name__)
cors = CORS(app, resources={r"/*": {"origins": "*"}})

@app.route('/api/data')
def get_data_endpoint():
    data = series.get_data()  # Call the function to fetch data from the MySQL database
    response = make_response(jsonify(data))
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'GET'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    
    return response  # Convert the data to JSON format and return it as the response

if __name__ == '__main__':
    app.run()
